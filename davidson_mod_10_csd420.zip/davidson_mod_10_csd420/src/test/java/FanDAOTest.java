import org.junit.jupiter.api.Test;

import java.sql.SQLException;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * FanDAOTest verifies the database methods used by the JavaFX interface.
 *
 * These tests require a local MySQL database named databasedb with the fans
 * table already created. This matches the assignment because the application is
 * not supposed to create or delete the table.
 *
 * Before running the tests, make sure at least one record exists with ID 1.
 *
 * Author: Tiffany Davidson
 * Date: 2026-05-17
 * Assignment: Module 10.2 CSD420
 */
public class FanDAOTest {

    /**
     * Confirms that an existing fan can be selected by ID.
     *
     * @throws SQLException if the database query fails
     */
    @Test
    public void testFindFanById() throws SQLException {
        FanDAO dao = new FanDAO();
        Optional<Fan> fan = dao.findFanById(1);

        assertTrue(fan.isPresent(), "A fan with ID 1 should exist for this test.");
        assertEquals(1, fan.get().getId());
    }

    /**
     * Confirms that a fan record can be updated and then changed back.
     *
     * @throws SQLException if the database update fails
     */
    @Test
    public void testUpdateFan() throws SQLException {
        FanDAO dao = new FanDAO();
        Optional<Fan> originalFanResult = dao.findFanById(1);

        assertTrue(originalFanResult.isPresent(), "A fan with ID 1 should exist for this test.");

        Fan originalFan = originalFanResult.get();
        Fan updatedFan = new Fan(1, "TestFirst", "TestLast", "TestTeam");

        assertTrue(dao.updateFan(updatedFan), "The update should affect one row.");

        Optional<Fan> changedFanResult = dao.findFanById(1);
        assertTrue(changedFanResult.isPresent(), "The updated fan should still exist.");
        assertEquals("TestFirst", changedFanResult.get().getFirstName());
        assertEquals("TestLast", changedFanResult.get().getLastName());
        assertEquals("TestTeam", changedFanResult.get().getFavoriteTeam());

        assertTrue(dao.updateFan(originalFan), "The original fan data should be restored.");
    }
}
