/**
 * DatabaseConfig stores the database connection settings for Module 10.2.
 *
 * The assignment requires the database name to be databasedb, the user ID to be
 * student1, and the password to be pass. The application does not create or
 * delete the table. It only reads and updates existing fan records.
 *
 * Author: Tiffany Davidson
 * Date: 2026-05-17
 * Assignment: Module 10.2 CSD420
 */
public final class DatabaseConfig {

    public static final String URL = "jdbc:mysql://localhost:3306/databasedb";
    public static final String USER = "student1";
    public static final String PASSWORD = "pass";

    private DatabaseConfig() {
        // Prevent this utility class from being created as an object.
    }
}
