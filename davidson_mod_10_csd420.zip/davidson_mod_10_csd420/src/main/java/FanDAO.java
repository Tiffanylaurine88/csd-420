import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Optional;

/**
 * FanDAO handles database work for the fans table.
 *
 * This class uses prepared statements so user input is handled safely. It does
 * not create or delete the fans table because the assignment says the table will
 * already exist when the application is tested.
 *
 * Author: Tiffany Davidson
 * Date: 2026-05-17
 * Assignment: Module 10.2 CSD420
 */
public class FanDAO {

    /**
     * Opens a connection to the databasedb MySQL database.
     *
     * @return an active database connection
     * @throws SQLException if the database connection fails
     */
    protected Connection getConnection() throws SQLException {
        return DriverManager.getConnection(DatabaseConfig.URL, DatabaseConfig.USER, DatabaseConfig.PASSWORD);
    }

    /**
     * Finds a fan record by the provided ID.
     *
     * @param id the fan ID entered by the user
     * @return an Optional containing the fan when found, or an empty Optional when not found
     * @throws SQLException if the SQL query fails
     */
    public Optional<Fan> findFanById(int id) throws SQLException {
        String sql = "SELECT ID, firstname, lastname, favoriteteam FROM fans WHERE ID = ?";

        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, id);

            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    Fan fan = new Fan(
                            resultSet.getInt("ID"),
                            resultSet.getString("firstname"),
                            resultSet.getString("lastname"),
                            resultSet.getString("favoriteteam")
                    );
                    return Optional.of(fan);
                }
            }
        }

        return Optional.empty();
    }

    /**
     * Updates an existing fan record in the fans table.
     *
     * @param fan the fan values from the display fields
     * @return true when one row was updated, false when no row matched the ID
     * @throws SQLException if the SQL update fails
     */
    public boolean updateFan(Fan fan) throws SQLException {
        String sql = "UPDATE fans SET firstname = ?, lastname = ?, favoriteteam = ? WHERE ID = ?";

        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setString(1, fan.getFirstName());
            statement.setString(2, fan.getLastName());
            statement.setString(3, fan.getFavoriteTeam());
            statement.setInt(4, fan.getId());

            int rowsUpdated = statement.executeUpdate();
            return rowsUpdated == 1;
        }
    }
}
