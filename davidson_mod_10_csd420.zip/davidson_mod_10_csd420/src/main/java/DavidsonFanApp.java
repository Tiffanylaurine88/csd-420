import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.GridPane;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.sql.SQLException;
import java.util.Optional;

/**
 * DavidsonFanApp is a JavaFX application for Module 10.2.
 *
 * The application allows the user to enter a fan ID, display the matching fan
 * record from the database, edit the displayed information, and update the same
 * record in the database.
 *
 * The required database is databasedb. The required table is fans. This
 * application does not create or delete the table.
 *
 * Author: Tiffany Davidson
 * Date: 2026-05-17
 * Assignment: Module 10.2 CSD420
 */
public class DavidsonFanApp extends Application {

    private final FanDAO fanDAO = new FanDAO();

    private TextField idField;
    private TextField firstNameField;
    private TextField lastNameField;
    private TextField favoriteTeamField;

    /**
     * Builds and displays the JavaFX interface.
     *
     * @param primaryStage the main JavaFX stage
     */
    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Module 10.2 Fan Database");

        Label idLabel = new Label("Fan ID:");
        Label firstNameLabel = new Label("First Name:");
        Label lastNameLabel = new Label("Last Name:");
        Label favoriteTeamLabel = new Label("Favorite Team:");

        idField = new TextField();
        firstNameField = new TextField();
        lastNameField = new TextField();
        favoriteTeamField = new TextField();

        Button displayButton = new Button("Display");
        Button updateButton = new Button("Update");

        displayButton.setOnAction(event -> displayFanRecord());
        updateButton.setOnAction(event -> updateFanRecord());

        GridPane gridPane = new GridPane();
        gridPane.setPadding(new Insets(20));
        gridPane.setHgap(10);
        gridPane.setVgap(12);

        gridPane.add(idLabel, 0, 0);
        gridPane.add(idField, 1, 0);
        gridPane.add(firstNameLabel, 0, 1);
        gridPane.add(firstNameField, 1, 1);
        gridPane.add(lastNameLabel, 0, 2);
        gridPane.add(lastNameField, 1, 2);
        gridPane.add(favoriteTeamLabel, 0, 3);
        gridPane.add(favoriteTeamField, 1, 3);
        gridPane.add(displayButton, 0, 4);
        gridPane.add(updateButton, 1, 4);

        Scene scene = new Scene(gridPane, 420, 250);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /**
     * Reads the ID entered by the user and displays the matching fan record.
     */
    private void displayFanRecord() {
        Integer id = parseIdFromField();
        if (id == null) {
            return;
        }

        try {
            Optional<Fan> fanResult = fanDAO.findFanById(id);

            if (fanResult.isPresent()) {
                Fan fan = fanResult.get();
                idField.setText(String.valueOf(fan.getId()));
                firstNameField.setText(fan.getFirstName());
                lastNameField.setText(fan.getLastName());
                favoriteTeamField.setText(fan.getFavoriteTeam());
                showInfo("Record Found", "Fan record loaded successfully.");
            } else {
                clearDisplayFieldsExceptId();
                showInfo("No Record Found", "No fan record was found for ID " + id + ".");
            }
        } catch (SQLException exception) {
            showError("Database Error", exception.getMessage());
        }
    }

    /**
     * Updates the fan record using the values currently shown in the text fields.
     */
    private void updateFanRecord() {
        Integer id = parseIdFromField();
        if (id == null) {
            return;
        }

        if (isBlank(firstNameField.getText()) || isBlank(lastNameField.getText()) || isBlank(favoriteTeamField.getText())) {
            showError("Missing Information", "First name, last name, and favorite team are required.");
            return;
        }

        Fan fan = new Fan(
                id,
                firstNameField.getText().trim(),
                lastNameField.getText().trim(),
                favoriteTeamField.getText().trim()
        );

        try {
            boolean updated = fanDAO.updateFan(fan);

            if (updated) {
                showInfo("Record Updated", "Fan record updated successfully.");
            } else {
                showInfo("No Record Updated", "No fan record was found for ID " + id + ".");
            }
        } catch (SQLException exception) {
            showError("Database Error", exception.getMessage());
        }
    }

    /**
     * Converts the ID field to an integer and validates that it is usable.
     *
     * @return the ID as an Integer, or null when the value is invalid
     */
    private Integer parseIdFromField() {
        try {
            return Integer.parseInt(idField.getText().trim());
        } catch (NumberFormatException exception) {
            showError("Invalid ID", "Please enter a valid numeric fan ID.");
            return null;
        }
    }

    /**
     * Clears the editable display fields but keeps the ID typed by the user.
     */
    private void clearDisplayFieldsExceptId() {
        firstNameField.clear();
        lastNameField.clear();
        favoriteTeamField.clear();
    }

    /**
     * Checks whether a value is null, empty, or only spaces.
     *
     * @param value the text value to check
     * @return true when the value is blank, otherwise false
     */
    private boolean isBlank(String value) {
        return value == null || value.trim().isEmpty();
    }

    /**
     * Shows an information message to the user.
     *
     * @param title the alert title
     * @param message the alert message
     */
    private void showInfo(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    /**
     * Shows an error message to the user.
     *
     * @param title the alert title
     * @param message the alert message
     */
    private void showError(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    /**
     * Starts the JavaFX application.
     *
     * @param args command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
}
