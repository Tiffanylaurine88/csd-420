# Davidson Module 10.2 CSD420

## Assignment
This JavaFX program displays and updates fan information stored in a MySQL database.

## Required Database
Database name: `databasedb`

User ID: `student1`

Password: `pass`

Table name: `fans`

Fields:

```sql
ID INTEGER PRIMARY KEY
firstname VARCHAR(25)
lastname VARCHAR(25)
favoriteteam VARCHAR(25)
```

## Important Note
The application does not create or delete the `fans` table. The assignment says the table will already exist and be populated when the application is tested.

The included `setup_test_data.sql` file is only for local home testing.

## Run the Program with Maven
From this folder, run:

```bash
mvn clean javafx:run
```

## Run the Tests
Make sure the local database exists and has a fan with ID 1. Then run:

```bash
mvn test
```

## Interface Test Steps
1. Start the JavaFX application.
2. Enter `1` in the Fan ID field.
3. Click Display.
4. Confirm the first name, last name, and favorite team fields populate.
5. Change the favorite team value.
6. Click Update.
7. Click Display again for ID `1`.
8. Confirm the updated value is shown.
9. Test a missing ID and confirm the app shows a message.
10. Test a nonnumeric ID and confirm the app shows an error.
