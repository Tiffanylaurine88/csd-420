-- Optional local setup script for testing at home.
-- The Java application does not create or delete the table.
-- This script is only for your own local database testing.

CREATE DATABASE IF NOT EXISTS databasedb;

CREATE USER IF NOT EXISTS 'student1'@'localhost' IDENTIFIED BY 'pass';
GRANT ALL PRIVILEGES ON databasedb.* TO 'student1'@'localhost';
FLUSH PRIVILEGES;

USE databasedb;

CREATE TABLE IF NOT EXISTS fans (
    ID INTEGER PRIMARY KEY,
    firstname VARCHAR(25),
    lastname VARCHAR(25),
    favoriteteam VARCHAR(25)
);

INSERT INTO fans (ID, firstname, lastname, favoriteteam) VALUES
(1, 'Tiffany', 'Davidson', 'Kansas City Chiefs'),
(2, 'John', 'Smith', 'Dallas Cowboys'),
(3, 'Mary', 'Jones', 'Arkansas Razorbacks')
ON DUPLICATE KEY UPDATE
firstname = VALUES(firstname),
lastname = VALUES(lastname),
favoriteteam = VALUES(favoriteteam);
